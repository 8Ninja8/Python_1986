bit_and = 5 & 6
bit_or = 5 | 6
bit_xor = 5 ^ 6

print(f'Выполнение логических побитовых операций над числами 5 и 6:\n'
      f'5 & 6 = {bit_and}\n'
      f'5 | 6 = {bit_or}\n'
      f'5 ^ 6 = {bit_xor}')